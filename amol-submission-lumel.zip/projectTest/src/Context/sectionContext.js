import { createContext } from "react";

const _sectionContext = createContext();
export default _sectionContext;
