import { createContext } from "react";

const _tableContex = createContext(null);
export default _tableContex;
